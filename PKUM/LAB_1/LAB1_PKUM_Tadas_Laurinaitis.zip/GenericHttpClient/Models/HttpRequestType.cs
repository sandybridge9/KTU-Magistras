﻿namespace GenericHttpClient.Models
{
    public enum HttpRequestType
    {
        GET,
        POST,
        PUT,
        DELETE
    }
}
