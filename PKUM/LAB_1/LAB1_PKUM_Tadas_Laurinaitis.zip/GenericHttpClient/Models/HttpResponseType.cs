﻿namespace GenericHttpClient.Models
{
    public enum HttpResponseType
    {
        Success,
        Failure,
        Empty,
        Undeserializable
    }
}
